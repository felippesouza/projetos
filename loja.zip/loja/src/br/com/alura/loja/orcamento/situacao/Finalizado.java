package br.com.alura.loja.orcamento.situacao;

public class Finalizado extends SituacaoOrcamento {
	

}
